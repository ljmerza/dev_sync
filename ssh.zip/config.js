let config = {
	host: 'rldv0211.gcsc.att.com',
	port: 22,
	attuid: 'lm240n',
	myPort: 8173
};

config.remoteBase = `/opt/app/${config.attuid}`;
config.ppkFilePath = `C:\\Users\\${config.attuid}\\.ssh\\id_rsa.ppk`,

config.udApiPort = '2'+config.myPort;
config.teamdbApiPort = '3'+config.myPort;
config.aqeApiPort = '1'+config.myPort;

config.localPaths = {
	ud: 'ud/UD_Cluster/www/UD',
	aqe: 'aqe/www/aqe',
	wam: 'wam/www/wam',
	upm: 'upm/www/upm',
	tqi: 'tqi/www/tqi3',
	taskmaster: 'taskmaster/www/taskmaster',
	templates: 'templates/www/Templates',
	modules: 'modules',
	ud_api: 'UD_api',
	upm_api: 'upm_api',
	aqe_api: 'aqe_api',
	teamdbapi: 'teamdbapi/src',
	template_api: 'template_api/src',
	wam_cron: 'wam/cron/automation/wam',
	aqe_cron: 'aqe/cron',
	ud_cron: 'ud/automation',
	ud_ember: 'UD_ember/UD',
	teamdb_ember: 'teamdb_ember/teamdb',
	template_ember: 'template_tool_ember/Template',
	dev_scripts: 'dev_scripts'
}

config.remotePaths = {
	ud: 'www/UD',
	aqe: 'www/aqe',
	wam: 'www/wam',
	upm: 'www/upm',
	tqi: 'www/tqi3',
	templates: 'Templates',

	modules: 'includes',
	external_modules: 'includes',
	dev_scripts: 'includes/dev_scripts',
	
	ud_api: 'www/UD_api',
	upm_api: 'www/upm_api',
	aqe_api: 'www/aqe_api',
	teamdbapi: 'www/teamdbapi',
	template_api: 'www/template_api',

	wam_cron: 'cron/wam',
	aqe_cron: 'cron/aqe',
	ud_cron: 'cron/ud',
	ud_ember: 'www/UD_ember/UD',
	teamdb_ember: 'www/teamdb_ember/teamdb',
	template_ember: 'www/template_ember/Template',
}

config.hypnotoadPaths = {
	ud_api: 'www/UD_api/ud_server.pl',
	upm_api: 'www/upm_api/UPM.pl',
	aqe_api: 'www/aqe_api/AQE.pl',
	teamdbapi: 'www/teamdbapi/teamdb.pl',
	wam_api: 'www/wam_api/WAM.pl',
	template_api: 'www/template_api/template.pl',
}

config.logFiles = [
	['logs', 'm5_log.log','logs/m5.log'],
	['logs', 'error_log', 'logs/error.log'],
	['logs', 'better_error_log', 'logs/better_error_log.log'],
	['logs', 'access_log', 'logs/access_log.log'],
	['www/UD_api/log', 'production.log', 'logs/UD_api.log'],
	['www/teamdbapi/logs', 'error.log', 'logs/teamdbapi.log'],
	['www/wam_api/log', 'production.log', 'logs/WAM_api.log'],
	['www/aqe_api/log', 'production.log', 'logs/AQE_api.log'],
	['www/upm_api/log', 'production.log', 'logs/UPM_api.log'],
	['www/template_api/logs', 'access.log', 'logs/template_api_access.log'],
	['www/template_api/logs', 'error.log', 'logs/template_api_error.log'],
];

module.exports = config;

