import requests

session_obj = requests.session()


url = 'localhost:28173/order/ethernet/C92MCDC8?attuid=lm240n'
filter_data = session_obj.get(
	url=url, 
	verify=False 
)
print(filter_data.text)